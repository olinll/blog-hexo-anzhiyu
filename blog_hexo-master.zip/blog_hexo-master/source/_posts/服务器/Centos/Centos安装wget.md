---
title: Centos 安装 Wget
categories:
   - 服务器
cover: >-
  https://pan.jianglin.cc:8443/d/images/2025/06/01/4f0236edf1a2782c1434cbba171a2fff.png
main_color: '#303030'
tags:
  - Wget
  - Centos
  - 食用教程
abbrlink: 13f0
date: 2022-08-15 00:11:00
---

# Centos安装wget

提示-bash: wget: 未找到命令 就需要安装wget

1. 输入 指令进行安装

   ~~~
   yum install wget
   ~~~

2. 等待安装

   ![image-20220413103602833](https://olinl-note.oss-cn-shanghai.aliyuncs.com/note/202402072011204.png)

3. 出现以下界面输入y回车就行

   ~~~
   y # 回车
   ~~~

   

4. 安装成功

   ![image-20220413103646715](https://olinl-note.oss-cn-shanghai.aliyuncs.com/note/202402072011968.png)
