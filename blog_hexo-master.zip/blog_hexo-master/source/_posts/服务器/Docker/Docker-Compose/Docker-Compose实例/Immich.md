---
title: Docker-compose实例 Immich
categories:
  - 服务器
tags:
  - Docker
  - Docker-Compose
  - Immich
abbrlink: 4bdb
date: 2025-02-24 21:33:08
---

Immich‌是一款自托管的照片和视频管理软件，旨在帮助用户轻松备份、组织和管理自己的照片和视频，同时保护用户的隐私。它支持网页版、安卓端和苹果端，用户可以在多个设备上同步使用‌

官网：[https://immich.app](https://immich.app)



Docker-compose安装：

参考：[https://immich.app/docs/install/docker-compose](https://immich.app/docs/install/docker-compose)

immich智能相册更换支持中文搜索的CLIP大模型教程

参考：[https://www.bilibili.com/opus/921308194821636097](https://www.bilibili.com/opus/921308194821636097)

